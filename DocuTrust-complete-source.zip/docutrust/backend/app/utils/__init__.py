"""Backend utility helpers."""
