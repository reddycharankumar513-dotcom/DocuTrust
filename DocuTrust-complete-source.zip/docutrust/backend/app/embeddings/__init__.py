"""Embedding providers."""
